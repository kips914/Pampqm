package com.warhead.item;

import com.warhead.WarheadConfig;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.item.PrimedTnt;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/** Lightweight missile-only visuals; bomber flight and bomb bay are handled by BomberEntity. */
@Mod.EventBusSubscriber(modid = "warhead")
public final class BomberGameplayEvents {
    private BomberGameplayEvents() {}

    @SubscribeEvent
    public static void onLevelTick(TickEvent.LevelTickEvent event) {
        if (event.phase != TickEvent.Phase.END || !(event.level instanceof ServerLevel level)) return;
        for (Entity entity : level.getAllEntities()) {
            if (!(entity instanceof PrimedTnt missile) || !missile.hasCustomName()
                    || !"Warhead Missile".equals(missile.getCustomName().getString())) continue;
            int quality = WarheadConfig.EFFECTS_LEVEL.get();
            if (quality > 0 && missile.tickCount % (quality == 3 ? 1 : 3) == 0) {
                level.sendParticles(ParticleTypes.SMOKE, missile.getX(), missile.getY(), missile.getZ(),
                        quality == 3 ? 3 : 1, 0.08, 0.08, 0.08, 0.01);
                if (quality >= 2) level.sendParticles(ParticleTypes.FLAME, missile.getX(), missile.getY(), missile.getZ(),
                        1, 0.04, 0.04, 0.04, 0.005);
            }
            if (WarheadConfig.SOUND_EFFECTS.get() && missile.tickCount == 1) {
                level.playSound(null, missile.blockPosition(), SoundEvents.FIREWORK_ROCKET_LAUNCH,
                        SoundSource.HOSTILE, (float) (0.9F * WarheadConfig.SOUND_VOLUME.get()), 0.7F);
            }
        }
    }
}
