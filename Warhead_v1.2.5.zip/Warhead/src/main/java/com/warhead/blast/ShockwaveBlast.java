package com.warhead.blast;

import com.warhead.block.BombBlock;
import com.warhead.WarheadConfig;
import com.warhead.net.ModNet;
import com.warhead.net.ShakePacket;
import com.warhead.radiation.RadiationManager;
import it.unimi.dsi.fastutil.longs.Long2FloatOpenHashMap;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleOptions;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.RandomSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.item.FallingBlockEntity;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.network.PacketDistributor;

import java.util.HashSet;
import java.util.PriorityQueue;
import java.util.Set;
import java.util.UUID;

/**
 * Ударная волна как поиск кратчайшего пути (Дейкстра) по воксельной сетке, 26 соседей.
 *
 *  d    — "эффективная длина пути" от эпицентра. Воздух: шаг = длине шага. Твёрдый блок: шаг умножается на
 *         (1 + K_COST * взрывоустойчивость) — стена замедляет и "съедает" волну.
 *  P(d) — давление на фронте = power / (1 + FALLOFF * d^3).
 *
 * Следствия, которых нет у обычных лучевых взрывов:
 *  - волна огибает углы и затекает в ямы/туннели/комнаты (путь через проём короче, чем через стену);
 *  - волна распространяется со временем: за тик обрабатывается порция клеток (фронт = рост d), так видно "бегущую" волну;
 *  - сущности получают урон по давлению в ИХ клетке, а не по прямой дистанции — за стеной/в укрытии слабее.
 */
public class ShockwaveBlast {
    // ---- настройки (потом вынесем в конфиг) ----
    private static final float K_COST = 0.15f;       // сопротивление блока -> удлинение пути
    private static final float BREAK_BASE = 4f;      // порог разрушения = BREAK_BASE + взрывоустойчивость
    private static final float FALLOFF = 0.05f;      // скорость спада давления
    private static final float PROPAGATE_MIN = 3f;   // ниже этого давления волна дальше не считается
    private static final float SCORCH_MIN = 3f;      // ядерка: обугливание блоков, которые не разрушены
    private static final long BUDGET_NS = 18_000_000L; // бюджет времени на тик
    private static final int CLOUD_TICKS = 700;
    private static final double FLASH_RANGE = 1500;

    private static final int[][] DIRS = new int[26][];
    private static final float[] LEN = new float[26];
    static {
        int i = 0;
        for (int x = -1; x <= 1; x++) for (int y = -1; y <= 1; y++) for (int z = -1; z <= 1; z++) {
            if (x == 0 && y == 0 && z == 0) continue;
            DIRS[i] = new int[]{x, y, z};
            LEN[i] = (float) Math.sqrt(x * x + y * y + z * z);
            i++;
        }
    }

    private record Node(long pos, float d) {}

    private final ServerLevel level;
    private final Vec3 origin;
    private final BlockPos originPos;
    private final BlastProfile profile;
    private final PriorityQueue<Node> queue = new PriorityQueue<>((a, b) -> Float.compare(a.d, b.d));
    private final Long2FloatOpenHashMap best = new Long2FloatOpenHashMap();
    private final Set<UUID> hit = new HashSet<>();
    private float frontier = 0f;
    private int age = 0;
    private boolean cleaned = false;
    private int debrisCreated = 0;
    private int collapseSoundBursts = 0;

    public ShockwaveBlast(ServerLevel level, Vec3 origin, BlastProfile profile) {
        this.level = level;
        this.origin = origin;
        this.originPos = BlockPos.containing(origin);
        this.profile = profile;
        best.defaultReturnValue(Float.MAX_VALUE);
        long key = originPos.asLong();
        best.put(key, 0f);
        queue.add(new Node(key, 0f));

        if (WarheadConfig.SOUND_EFFECTS.get()) {
            level.playSound(null, originPos, SoundEvents.GENERIC_EXPLODE, SoundSource.BLOCKS,
                    (profile.nuclear ? 200f : 60f) * WarheadConfig.SOUND_VOLUME.get().floatValue(), profile.nuclear ? 0.35f : 0.6f);
        }
        if (profile.nuclear) {
            RadiationManager.contaminate(level, origin, profile.radStrength, profile.radRadius);
            flashCheck();
        }
    }

    public ServerLevel level() { return level; }

    private float pressure(float d) {
        return profile.power / (1f + FALLOFF * d * d * d);
    }

    /** @return true, когда взрыв полностью закончен */
    public boolean tick() {
        age++;
        if (!queue.isEmpty()) {
            advance();
        } else if (!cleaned) {
            best.clear();
            best.trim();
            cleaned = true;
        }
        if (profile.nuclear && age < CLOUD_TICKS) {
            int particleInterval = Math.max(WarheadConfig.PARTICLE_INTERVAL.get(), WarheadConfig.EFFECTS_LEVEL.get() == 1 ? 3 : 1);
            if (age % particleInterval == 0) cloud();
            if (age % 10 == 0) flashCheck();
        }
        return queue.isEmpty() && (!profile.nuclear || age >= CLOUD_TICKS);
    }

    private void advance() {
        long start = System.nanoTime();
        BlockPos.MutableBlockPos p = new BlockPos.MutableBlockPos();
        BlockPos.MutableBlockPos q = new BlockPos.MutableBlockPos();
        float maxSq = (float) profile.maxRadius * profile.maxRadius;
        int n = 0;

        while (!queue.isEmpty()) {
            if ((++n & 127) == 0 && System.nanoTime() - start > BUDGET_NS) break;
            Node node = queue.poll();
            if (node.d > best.get(node.pos)) continue; // устаревшая запись
            frontier = node.d;

            int x = BlockPos.getX(node.pos), y = BlockPos.getY(node.pos), z = BlockPos.getZ(node.pos);
            p.set(x, y, z);
            float pr = pressure(node.d);
            BlockState st = level.getBlockState(p);
            float res = 0f;

            if (!st.isAir()) {
                res = st.getBlock().getExplosionResistance();
                boolean unbreakable = st.getDestroySpeed(level, p) < 0f;
                if (!unbreakable && pr > BREAK_BASE + res) {
                    if (st.getBlock() instanceof BombBlock bomb) {
                        BlastManager.start(level, Vec3.atCenterOf(p), bomb.profile()); // цепная детонация
                    }
                    // Сильная волна не просто удаляет блок: она выбрасывает обломок,
                    // а скорость зависит от давления в данной точке и сопротивления материала.
                    // Never silently delete inventories or other block-entity data.
                    if (!st.hasBlockEntity()) {
                        if (WarheadConfig.ENABLE_DEBRIS.get() && debrisCreated < WarheadConfig.MAX_DEBRIS_PER_BLAST.get()) {
                            ejectBlock(p.immutable(), st, pr, x, y, z);
                            debrisCreated++;
                        } else {
                            level.setBlock(p, Blocks.AIR.defaultBlockState(), 2 | 16 | 32);
                        }
                        // Underground roof collapse is a separate, configurable structural pass.
                        if (WarheadConfig.ENABLE_COLLAPSE.get() && y < 60 && pr > BREAK_BASE + res + 8f) collapseWeakRoof(p.immutable(), pr);
                    }
                } else if (profile.nuclear && pr > SCORCH_MIN) {
                    Scorch.apply(level, p, st);
                }
            }

            float factor = 1f + K_COST * res;
            for (int i = 0; i < 26; i++) {
                int nx = x + DIRS[i][0], ny = y + DIRS[i][1], nz = z + DIRS[i][2];
                if (level.isOutsideBuildHeight(ny)) continue;
                float nd = node.d + LEN[i] * factor;
                if (pressure(nd) < PROPAGATE_MIN) continue;
                float dx = nx - originPos.getX(), dy = ny - originPos.getY(), dz = nz - originPos.getZ();
                if (dx * dx + dy * dy + dz * dz > maxSq) continue;
                q.set(nx, ny, nz);
                long key = q.asLong();
                if (nd >= best.get(key)) continue;
                if (!level.hasChunkAt(q)) continue;
                best.put(key, nd);
                queue.add(new Node(key, nd));
            }
        }
        affectEntities(queue.isEmpty() ? Float.MAX_VALUE : frontier);
    }


    /** Превращает разрушенный блок в физический обломок. Скорость ограничена, чтобы не разгонять сущности чрезмерно. */
    private void ejectBlock(BlockPos pos, BlockState state, float pr, int x, int y, int z) {
        if (state.isAir() || state.getDestroySpeed(level, pos) < 0f || state.hasBlockEntity()) return;
        double dx = x + 0.5 - origin.x;
        double dy = y + 0.5 - origin.y;
        double dz = z + 0.5 - origin.z;
        Vec3 dir = new Vec3(dx, dy, dz);
        if (dir.lengthSqr() < 1.0e-5) dir = new Vec3(level.random.nextDouble() - 0.5, 0.3, level.random.nextDouble() - 0.5);
        dir = dir.normalize();
        // Около 1–5 блоков/с в зависимости от силы волны; более тяжёлые материалы летят меньше.
        double strength = Math.max(0.35, Math.min(1.65, Math.sqrt(Math.max(0f, pr)) * 0.055));
        double resistanceFactor = 1.0 / (1.0 + Math.max(0f, state.getBlock().getExplosionResistance()) * 0.035);
        FallingBlockEntity debris = FallingBlockEntity.fall(level, pos.immutable(), state);
        debris.setDeltaMovement(dir.x * strength * resistanceFactor,
                Math.max(0.12, dir.y * strength * resistanceFactor + 0.18),
                dir.z * strength * resistanceFactor);
        debris.dropItem = true;
        level.setBlock(pos, Blocks.AIR.defaultBlockState(), 2 | 16 | 32);
    }

    /** Простая модель обрушения: в подземной полости блоки потолка без опоры превращаются в падающие обломки. */
    private void collapseWeakRoof(BlockPos breach, float pr) {
        int radius = pr > 90f ? 2 : 1;
        int maxBlocks = pr > 180f ? 18 : 7;
        int moved = 0;
        // Sounds are emitted only if at least one roof block actually gives way.
        for (int dy = 1; dy <= 3 && moved < maxBlocks; dy++) {
            for (int dx = -radius; dx <= radius && moved < maxBlocks; dx++) {
                for (int dz = -radius; dz <= radius && moved < maxBlocks; dz++) {
                    BlockPos roof = breach.offset(dx, dy, dz);
                    if (!level.hasChunkAt(roof) || level.isOutsideBuildHeight(roof.getY())) continue;
                    BlockState st = level.getBlockState(roof);
                    if (st.isAir() || st.getDestroySpeed(level, roof) < 0f || st.hasBlockEntity()) continue;
                    // Только блоки над пустотой: это потолок/перекрытие, потерявшее опору.
                    if (!level.getBlockState(roof.below()).isAir()) continue;
                    if (level.random.nextFloat() > Math.min(0.9f, 0.25f + pr / 250f)) continue;
                    ejectBlock(roof, st, pr * 0.35f, roof.getX(), roof.getY(), roof.getZ());
                    moved++;
                }
            }
        }
        if (moved > 0) {
            // A short, rate-limited sequence: crack first, then rubble falling.
            playCollapseSound(breach, false);
            playCollapseSound(breach, true);
        }
    }

    /** Rate-limited structural audio: a heavy stone crack followed by gravel/rubble falling. */
    private void playCollapseSound(BlockPos pos, boolean rubble) {
        if (!WarheadConfig.SOUND_EFFECTS.get() || !WarheadConfig.COLLAPSE_SOUNDS.get() || collapseSoundBursts >= 3) return;
        float volume = (float) Math.max(0.0, Math.min(2.0, WarheadConfig.SOUND_VOLUME.get()));
        if (volume <= 0.001f) return;
        if (rubble) {
            level.playSound(null, pos, SoundEvents.GRAVEL_FALL, SoundSource.BLOCKS,
                    0.75f * volume, 0.72f + level.random.nextFloat() * 0.18f);
        } else {
            level.playSound(null, pos, SoundEvents.STONE_BREAK, SoundSource.BLOCKS,
                    1.0f * volume, 0.55f + level.random.nextFloat() * 0.15f);
        }
        collapseSoundBursts++;
    }

    private void affectEntities(float limit) {
        double r = limit == Float.MAX_VALUE ? profile.maxRadius + 4 : Math.min(limit + 3, profile.maxRadius + 4);
        AABB box = new AABB(origin, origin).inflate(r);
        for (Entity e : level.getEntities((Entity) null, box)) {
            if (e.isSpectator() || hit.contains(e.getUUID())) continue;
            float d = best.get(e.blockPosition().asLong());
            if (d == Float.MAX_VALUE || d > limit) continue; // волна ещё не дошла / не достанет
            hit.add(e.getUUID());

            float pr = pressure(d);
            Vec3 dir = e.position().subtract(origin);
            dir = dir.lengthSqr() < 1e-4 ? new Vec3(0, 1, 0) : dir.normalize();
            float s = (float) Math.min(Math.sqrt(pr) * 0.08, 6.0);
            e.setDeltaMovement(e.getDeltaMovement().add(dir.x * s, dir.y * s + s * 0.4, dir.z * s));
            e.hurtMarked = true;

            if (e instanceof LivingEntity le) {
                le.hurt(level.damageSources().explosion(null, null), pr * 0.35f);
            } else if (pr > 40f && !(e instanceof ServerPlayer)) {
                e.discard();
            }
            if (e instanceof ServerPlayer sp) {
                float k = Math.min(1.5f, (float) Math.sqrt(pr) / 15f);
                if (WarheadConfig.CAMERA_SHAKE.get()) {
                    ModNet.CH.send(PacketDistributor.PLAYER.with(() -> sp), new ShakePacket(k, 40 + (int) Math.min(200, pr)));
                }
            }
        }
    }

    // ------------------------------------------------ ядерные эффекты ------------------------------------------------

    /** Слепота у тех, кто смотрит на вспышку/гриб и видит его (нет блоков на линии взгляда). */
    private void flashCheck() {
        Vec3 target = origin.add(0, Math.min(age * 0.9, 130) * 0.6 + 10, 0);
        for (ServerPlayer pl : level.players()) {
            Vec3 eye = pl.getEyePosition();
            Vec3 to = target.subtract(eye);
            if (to.length() > FLASH_RANGE) continue;
            if (pl.getLookAngle().dot(to.normalize()) < 0.35) continue;
            HitResult hr = level.clip(new ClipContext(eye, target, ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, pl));
            if (hr.getType() != HitResult.Type.MISS) continue;
            int dur = age == 0 ? 300 : 40;
            pl.addEffect(new MobEffectInstance(MobEffects.BLINDNESS, dur, 0, false, false));
        }
    }

    private void emit(ParticleOptions type, double x, double y, double z) {
        int quality = WarheadConfig.EFFECTS_LEVEL.get();
        if (quality == 0) return;
        // One server broadcast instead of one send per player (avoids duplicate particle work).
        level.sendParticles(type, x, y, z, 1, 0.4, 0.4, 0.4, 0.0);
    }

    /** Грибовидное облако из частиц: огненный шар -> ножка -> шляпа (тор). Рендер-версия будет в этапе 2. */
    private void cloud() {
        RandomSource rnd = level.random;
        int quality = WarheadConfig.EFFECTS_LEVEL.get();
        if (quality == 0) return;
        double scale = quality == 1 ? 0.25 : quality == 2 ? 0.6 : 1.0;
        double rise = Math.min(age * 0.9, 130);

        if (age < 50) {
            double fr = Math.min(40, age * 1.0);
            for (int i = 0; i < Math.max(2, (int)(20 * scale)); i++) {
                Vec3 v = new Vec3(rnd.nextGaussian(), rnd.nextGaussian(), rnd.nextGaussian()).normalize().scale(fr * rnd.nextDouble());
                emit(ParticleTypes.FLAME, origin.x + v.x, origin.y + Math.abs(v.y), origin.z + v.z);
            }
        }

        double stemR = 4 + rise * 0.05;
        for (int i = 0; i < Math.max(3, (int)(20 * scale)); i++) {
            double h = rnd.nextDouble() * rise;
            double a = rnd.nextDouble() * Math.PI * 2;
            double r = stemR * (0.5 + rnd.nextDouble() * 0.7) * (1.0 - 0.35 * h / Math.max(rise, 1));
            ParticleOptions t = (age < 160 && h < rise * 0.4) ? ParticleTypes.FLAME : ParticleTypes.LARGE_SMOKE;
            emit(t, origin.x + Math.cos(a) * r, origin.y + h, origin.z + Math.sin(a) * r);
        }

        if (rise > 25) {
            double capR = Math.min(38, (rise - 25) * 0.55 + 6);
            for (int i = 0; i < Math.max(4, (int)(24 * scale)); i++) {
                double a = rnd.nextDouble() * Math.PI * 2;
                double phi = rnd.nextDouble() * Math.PI * 2;
                double r = capR + 9 * Math.cos(phi);
                double y = origin.y + rise + 8 * Math.sin(phi);
                ParticleOptions t = age < 120 ? ParticleTypes.FLAME : ParticleTypes.CLOUD;
                emit(t, origin.x + Math.cos(a) * r, y, origin.z + Math.sin(a) * r);
            }
        }
    }
}
