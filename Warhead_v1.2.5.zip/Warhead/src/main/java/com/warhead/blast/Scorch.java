package com.warhead.blast;

import com.warhead.registry.ModBlocks;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.tags.BlockTags;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.BushBlock;
import net.minecraft.world.level.block.SnowLayerBlock;
import net.minecraft.world.level.block.VineBlock;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.RotatedPillarBlock;
import net.minecraft.world.level.block.state.BlockState;

/** Последствия ядерного взрыва для блоков, переживших волну: пепел, обугливание, тёмные породы. */
public class Scorch {
    public static void apply(ServerLevel level, BlockPos pos, BlockState st) {
        Block b = st.getBlock();
        BlockState to = null;

        if (st.is(BlockTags.LEAVES) || st.is(BlockTags.FLOWERS) || st.is(BlockTags.CROPS) || st.is(BlockTags.SAPLINGS)
                || b instanceof BushBlock || b instanceof VineBlock || b instanceof SnowLayerBlock) {
            to = Blocks.AIR.defaultBlockState();
        } else if (st.is(BlockTags.LOGS)) {
            to = ModBlocks.CHARRED_LOG.get().defaultBlockState();
            if (st.hasProperty(RotatedPillarBlock.AXIS)) {
                to = to.setValue(RotatedPillarBlock.AXIS, st.getValue(RotatedPillarBlock.AXIS));
            }
        } else if (b == Blocks.GRASS_BLOCK || b == Blocks.DIRT || b == Blocks.PODZOL || b == Blocks.MYCELIUM
                || b == Blocks.COARSE_DIRT || b == Blocks.ROOTED_DIRT || b == Blocks.FARMLAND || b == Blocks.DIRT_PATH) {
            to = ModBlocks.ASH_GROUND.get().defaultBlockState();
        } else if (b == Blocks.STONE) {
            to = Blocks.DEEPSLATE.defaultBlockState();
        } else if (b == Blocks.COBBLESTONE) {
            to = Blocks.BLACKSTONE.defaultBlockState();
        }
        if (to != null) level.setBlock(pos, to, 2 | 16 | 32);
    }
}
