package com.warhead.radiation;

import it.unimi.dsi.fastutil.longs.Long2FloatOpenHashMap;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.Tag;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.ChunkPos;
import net.minecraft.world.level.saveddata.SavedData;

/** Уровень радиации на чанк (ед./сек), хранится в мире. */
public class RadiationSavedData extends SavedData {
    private final Long2FloatOpenHashMap map = new Long2FloatOpenHashMap();

    public static RadiationSavedData get(ServerLevel level) {
        return level.getDataStorage().computeIfAbsent(RadiationSavedData::load, RadiationSavedData::new, "warhead_radiation");
    }

    public static RadiationSavedData load(CompoundTag tag) {
        RadiationSavedData d = new RadiationSavedData();
        ListTag list = tag.getList("c", Tag.TAG_COMPOUND);
        for (int i = 0; i < list.size(); i++) {
            CompoundTag t = list.getCompound(i);
            d.map.put(t.getLong("p"), t.getFloat("v"));
        }
        return d;
    }

    @Override
    public CompoundTag save(CompoundTag tag) {
        ListTag list = new ListTag();
        for (long k : map.keySet().toLongArray()) {
            CompoundTag t = new CompoundTag();
            t.putLong("p", k);
            t.putFloat("v", map.get(k));
            list.add(t);
        }
        tag.put("c", list);
        return tag;
    }

    public float get(ChunkPos c) { return map.get(c.toLong()); }

    public void add(ChunkPos c, float v) {
        long k = c.toLong();
        map.put(k, map.get(k) + v);
        setDirty();
    }

    public void decay(float factor) {
        if (map.isEmpty()) return;
        for (long k : map.keySet().toLongArray()) {
            float nv = map.get(k) * factor;
            if (nv < 0.05f) map.remove(k); else map.put(k, nv);
        }
        setDirty();
    }
}
