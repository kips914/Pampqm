package com.warhead.radiation;

import com.warhead.WarheadMod;
import com.warhead.registry.ModBlocks;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.tags.ItemTags;
import net.minecraft.tags.TagKey;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.ChunkPos;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = WarheadMod.MODID)
public class RadiationManager {
    public static final String TAG = "warhead_rad";
    /** Предметы этого тега (4 слота брони) дают защиту. Сюда же можно добавлять предметы hbm — см. data/warhead/tags/items/hazmat.json */
    public static final TagKey<Item> HAZMAT = ItemTags.create(new ResourceLocation(WarheadMod.MODID, "hazmat"));

    private static final float DECAY_PER_SEC = 0.9993f; // период полураспада ~ 16 мин
    private static final float HAZMAT_FACTOR = 0.03f;

    /** Заражение чанков вокруг эпицентра: сила падает квадратично до нуля на радиусе. */
    public static void contaminate(ServerLevel level, Vec3 origin, float strength, int radiusBlocks) {
        RadiationSavedData data = RadiationSavedData.get(level);
        ChunkPos c0 = new ChunkPos(BlockPos.containing(origin));
        int cr = radiusBlocks / 16 + 1;
        for (int dx = -cr; dx <= cr; dx++) {
            for (int dz = -cr; dz <= cr; dz++) {
                double dist = Math.sqrt(dx * dx + dz * dz) * 16.0;
                if (dist > radiusBlocks) continue;
                double k = 1.0 - dist / radiusBlocks;
                data.add(new ChunkPos(c0.x + dx, c0.z + dz), (float) (strength * k * k));
            }
        }
    }

    @SubscribeEvent
    public static void onLevelTick(TickEvent.LevelTickEvent e) {
        if (e.phase != TickEvent.Phase.END || !(e.level instanceof ServerLevel sl)) return;
        if (sl.getGameTime() % 20 != 0) return;
        RadiationSavedData data = RadiationSavedData.get(sl);
        data.decay(DECAY_PER_SEC);
        for (ServerPlayer p : sl.players()) tickPlayer(sl, data, p);
    }

    private static void tickPlayer(ServerLevel sl, RadiationSavedData data, ServerPlayer p) {
        if (p.isCreative() || p.isSpectator()) return;
        CompoundTag pd = p.getPersistentData();
        float total = pd.getFloat(TAG);
        float amb = data.get(p.chunkPosition());

        total = Math.max(0f, total - 0.15f); // естественное выведение
        if (amb > 0.05f) {
            float protection = hasHazmat(p) ? HAZMAT_FACTOR : 1f;
            boolean respirator = p.getItemBySlot(net.minecraft.world.entity.EquipmentSlot.HEAD).is(com.warhead.registry.ModItems.GAS_MASK.get())
                    || p.getItemBySlot(net.minecraft.world.entity.EquipmentSlot.HEAD).is(com.warhead.registry.ModItems.HAZMAT_HELMET.get());
            boolean filterAvailable = p.getInventory().items.stream().anyMatch(st -> st.is(com.warhead.registry.ModItems.AIR_FILTER.get()));
            if (respirator && filterAvailable) protection *= hasHazmat(p) ? 0.05f : 0.25f;
            float dose = amb * shield(sl, p) * protection;
            total += dose;
            if (amb > 0.3f) {
                sl.sendParticles(p, ParticleTypes.ASH, true, p.getX(), p.getY() + 1, p.getZ(), 30, 8, 4, 8, 0.02);
                p.displayClientMessage(Component.translatable("msg.warhead.radiation",
                        String.format("%.0f", total), String.format("%.1f", dose)), true);
            }
        }
        pd.putFloat(TAG, total);

        if (total >= 150) p.addEffect(new MobEffectInstance(MobEffects.HUNGER, 60, 0, false, true));
        if (total >= 300) {
            p.addEffect(new MobEffectInstance(MobEffects.WEAKNESS, 60, 0, false, true));
            p.addEffect(new MobEffectInstance(MobEffects.CONFUSION, 100, 0, false, false));
        }
        if (total >= 600) p.addEffect(new MobEffectInstance(MobEffects.POISON, 40, 0, false, true));
        if (total >= 1000) p.addEffect(new MobEffectInstance(MobEffects.WITHER, 40, 1, false, true));
    }

    /** Радиация проходит сквозь всё, кроме свинца: 9 лучей вверх/по диагоналям, луч закрыт свинцовым блоком = минус 1/9 дозы. */
    private static float shield(ServerLevel sl, ServerPlayer p) {
        Vec3 eye = p.getEyePosition();
        int blocked = 0;
        for (int i = 0; i < 9; i++) {
            Vec3 dir = i == 0 ? new Vec3(0, 1, 0)
                    : new Vec3(Math.cos((i - 1) * Math.PI / 4), 1, Math.sin((i - 1) * Math.PI / 4)).normalize();
            for (int t = 1; t <= 10; t++) {
                BlockPos bp = BlockPos.containing(eye.add(dir.scale(t)));
                if (sl.getBlockState(bp).is(ModBlocks.LEAD_BLOCK.get())) { blocked++; break; }
            }
        }
        return 1f - blocked / 9f;
    }

    private static boolean hasHazmat(ServerPlayer p) {
        int n = 0;
        for (ItemStack s : p.getArmorSlots()) if (s.is(HAZMAT)) n++;
        return n >= 4;
    }
}
