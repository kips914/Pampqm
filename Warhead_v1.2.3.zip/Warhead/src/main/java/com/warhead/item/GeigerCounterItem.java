package com.warhead.item;

import com.warhead.radiation.RadiationManager;
import com.warhead.radiation.RadiationSavedData;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;

public class GeigerCounterItem extends Item {
    public GeigerCounterItem() { super(new Item.Properties().stacksTo(1).durability(256)); }
    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        if (!level.isClientSide && level instanceof ServerLevel sl) {
            float ambient = RadiationSavedData.get(sl).get(player.chunkPosition());
            float dose = player.getPersistentData().getFloat(RadiationManager.TAG);
            player.sendSystemMessage(Component.literal(String.format("☢ Гейгер | фон: %.3f | накопленная доза: %.1f", ambient, dose)));
            int clicks = ambient < 0.01f ? 0 : ambient < 0.05f ? 1 : ambient < 0.15f ? 2 : ambient < 0.4f ? 4 : 7;
            if (clicks > 0) {
                for (int i = 0; i < clicks; i++) level.playSound(null, player.blockPosition(), SoundEvents.STONE_BUTTON_CLICK_ON, SoundSource.PLAYERS, 0.25f, 1.5f + (i % 3) * 0.15f);
                stack.hurtAndBreak(1, player, p -> p.broadcastBreakEvent(hand));
            }
        }
        return InteractionResultHolder.sidedSuccess(stack, level.isClientSide());
    }
}
