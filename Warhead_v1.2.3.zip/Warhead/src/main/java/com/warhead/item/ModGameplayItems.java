package com.warhead.item;

import com.warhead.radiation.RadiationSavedData;
import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.EntityType;
import com.warhead.entity.BomberEntity;
import com.warhead.registry.ModEntities;
import net.minecraft.world.entity.item.PrimedTnt;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.chunk.LevelChunk;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.item.context.UseOnContext;

/** In-game target selection, missile launch and bomber deployment. */
public final class ModGameplayItems {
    private ModGameplayItems() {}

    public static class TargetMap extends Item {
        public TargetMap() { super(new Item.Properties().stacksTo(1)); }
        @Override public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
            ItemStack stack = player.getItemInHand(hand);
            if (level.isClientSide) return InteractionResultHolder.success(stack);
            HitResult hit = player.pick(128.0D, 0.0F, false);
            if (hit.getType() == HitResult.Type.BLOCK && hit instanceof BlockHitResult blockHit) {
                BlockPos p = blockHit.getBlockPos();
                CompoundTag tag = stack.getOrCreateTag();
                tag.putInt("TargetX", p.getX()); tag.putInt("TargetY", p.getY()); tag.putInt("TargetZ", p.getZ());
                tag.putString("TargetDimension", level.dimension().location().toString());
                player.sendSystemMessage(Component.literal("Цель отмечена: X=" + p.getX() + " Y=" + p.getY() + " Z=" + p.getZ()));
            } else player.sendSystemMessage(Component.literal("Наведи взгляд на блок в пределах 128 блоков и используй карту снова."));
            return InteractionResultHolder.sidedSuccess(stack, false);
        }
    }

    /** A field report item that prints coordinates from a target map in the player's inventory. */
    public static class CoordinateSheet extends Item {
        public CoordinateSheet() { super(new Item.Properties().stacksTo(16)); }
        @Override public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
            ItemStack stack = player.getItemInHand(hand);
            if (level.isClientSide) return InteractionResultHolder.success(stack);
            ItemStack map = ItemStack.EMPTY;
            for (ItemStack candidate : player.getInventory().items) {
                if (candidate.getItem() instanceof TargetMap && candidate.hasTag()
                        && candidate.getTag().contains("TargetX")) { map = candidate; break; }
            }
            if (map.isEmpty()) {
                player.sendSystemMessage(Component.literal("На листе пока нет координат. Сначала отметь цель на карте."));
                return InteractionResultHolder.fail(stack);
            }
            CompoundTag t = map.getTag();
            player.sendSystemMessage(Component.literal("Лист координат: X=" + t.getInt("TargetX")
                    + " Y=" + t.getInt("TargetY") + " Z=" + t.getInt("TargetZ")
                    + " | измерение: " + t.getString("TargetDimension")));
            return InteractionResultHolder.sidedSuccess(stack, false);
        }
    }

    public static class Missile extends Item {
        public Missile() { super(new Item.Properties().stacksTo(16)); }
        @Override public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
            ItemStack stack = player.getItemInHand(hand);
            if (level.isClientSide) return InteractionResultHolder.success(stack);
            ItemStack map = findTargetMap(player);
            if (map == null || !map.hasTag() || !map.getTag().contains("TargetX")) {
                player.sendSystemMessage(Component.literal("Сначала отметь цель на карте целей."));
                return InteractionResultHolder.fail(stack);
            }
            CompoundTag t = map.getTag();
            if (!t.getString("TargetDimension").equals(level.dimension().location().toString())) {
                player.sendSystemMessage(Component.literal("Цель находится в другом измерении."));
                return InteractionResultHolder.fail(stack);
            }
            BlockPos target = new BlockPos(t.getInt("TargetX"), t.getInt("TargetY"), t.getInt("TargetZ"));
            if (level instanceof ServerLevel sl && sl.hasChunkAt(target)) {
                // Launch a visible, moving warhead from above the player toward the marked target.
                double sx = player.getX();
                double sy = player.getY() + 18.0;
                double sz = player.getZ();
                PrimedTnt warhead = new PrimedTnt(level, sx, sy, sz, player);
                warhead.setCustomName(Component.literal("Warhead Missile"));
                warhead.setFuse(60);
                net.minecraft.world.phys.Vec3 direction = new net.minecraft.world.phys.Vec3(
                        target.getX() + 0.5 - sx,
                        target.getY() + 0.5 - sy,
                        target.getZ() + 0.5 - sz).normalize();
                warhead.setDeltaMovement(direction.scale(1.35).add(0.0, 0.15, 0.0));
                level.addFreshEntity(warhead);
                player.sendSystemMessage(Component.literal("Ракета запущена по координатам " + target.getX() + ", " + target.getY() + ", " + target.getZ()));
                if (!player.getAbilities().instabuild) stack.shrink(1);
                return InteractionResultHolder.sidedSuccess(stack, false);
            }
            player.sendSystemMessage(Component.literal("Цель не загружена в мире; подойди ближе и повтори запуск."));
            return InteractionResultHolder.fail(stack);
        }
        private ItemStack findTargetMap(Player player) {
            for (ItemStack s : player.getInventory().items) if (s.getItem() instanceof TargetMap) return s;
            for (ItemStack s : player.getInventory().offhand) if (s.getItem() instanceof TargetMap) return s;
            return ItemStack.EMPTY;
        }
    }

    public static class BomberController extends Item {
        public BomberController() { super(new Item.Properties().stacksTo(1).durability(64)); }
        @Override public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
            ItemStack stack = player.getItemInHand(hand);
            if (level.isClientSide) return InteractionResultHolder.success(stack);
            if (!(level instanceof ServerLevel sl)) return InteractionResultHolder.fail(stack);
            BlockPos target = player.blockPosition();
            net.minecraft.world.phys.Vec3 direction = player.getLookAngle();
            direction = new net.minecraft.world.phys.Vec3(direction.x, 0, direction.z).normalize();
            if (direction.lengthSqr() < 0.01) direction = new net.minecraft.world.phys.Vec3(0, 0, 1);
            BomberEntity bomber = ModEntities.BOMBER.get().create(level);
            if (bomber == null) return InteractionResultHolder.fail(stack);
            double startX = target.getX() + 0.5 - direction.x * 58.0;
            double startZ = target.getZ() + 0.5 - direction.z * 58.0;
            double altitude = Math.max(player.getY() + 30.0, level.getMinBuildHeight() + 20.0);
            bomber.moveTo(startX, altitude, startZ, player.getYRot(), 0);
            bomber.configureMission(target.getX() + 0.5, altitude, target.getZ() + 0.5, direction, 100);
            bomber.setCustomName(Component.literal("Warhead Bomber")); bomber.setCustomNameVisible(false);
            bomber.setPersistenceRequired(); level.addFreshEntity(bomber);
            player.sendSystemMessage(Component.literal("Бомбардировщик вызван. Пролёт и сброс бомбы через 5 секунд…"));
            if (!player.getAbilities().instabuild) stack.hurtAndBreak(1, player, p -> p.broadcastBreakEvent(hand));
            return InteractionResultHolder.sidedSuccess(stack, false);
        }
    }
}
