package com.warhead.item;

import com.warhead.radiation.RadiationManager;
import com.warhead.radiation.RadiationSavedData;
import com.warhead.registry.ModItems;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = "warhead")
public final class AirFilterEvents {
    private AirFilterEvents() {}
    @SubscribeEvent public static void onPlayerTick(TickEvent.PlayerTickEvent event) {
        if (event.phase != TickEvent.Phase.END || event.player.level().isClientSide || !(event.player instanceof Player player)) return;
        if (!(player.level() instanceof ServerLevel level) || player.tickCount % 20 != 0) return;
        float radiation = RadiationSavedData.get(level).get(player.chunkPosition());
        ItemStack held = player.getMainHandItem();
        if (held.is(ModItems.GEIGER_COUNTER.get()) && radiation > 0.01f) {
            int clicks = radiation < 0.05f ? 1 : radiation < 0.15f ? 2 : radiation < 0.4f ? 4 : 7;
            for (int i = 0; i < clicks; i++) level.playSound(null, player.blockPosition(), SoundEvents.STONE_BUTTON_CLICK_ON, SoundSource.PLAYERS, 0.2f, 1.4f + (i % 3) * 0.2f);
        }
        if (radiation <= 0.05f) return;
        ItemStack mask = player.getItemBySlot(EquipmentSlot.HEAD);
        boolean maskEquipped = mask.is(ModItems.GAS_MASK.get()) || mask.is(ModItems.HAZMAT_HELMET.get());
        boolean fullSuit = mask.is(ModItems.HAZMAT_HELMET.get())
                && player.getItemBySlot(EquipmentSlot.CHEST).is(ModItems.HAZMAT_CHEST.get())
                && player.getItemBySlot(EquipmentSlot.LEGS).is(ModItems.HAZMAT_LEGS.get())
                && player.getItemBySlot(EquipmentSlot.FEET).is(ModItems.HAZMAT_BOOTS.get());
        if (!maskEquipped) return;
        ItemStack filter = ItemStack.EMPTY;
        for (ItemStack s : player.getInventory().items) if (s.is(ModItems.AIR_FILTER.get())) { filter = s; break; }
        if (filter.isEmpty()) return;
        filter.shrink(1);
        if (fullSuit) player.sendSystemMessage(net.minecraft.network.chat.Component.literal("Фильтр израсходован: защита Hazmat работает."));
        else player.sendSystemMessage(net.minecraft.network.chat.Component.literal("Фильтр израсходован: противогаз защищает только дыхание."));
    }
}
