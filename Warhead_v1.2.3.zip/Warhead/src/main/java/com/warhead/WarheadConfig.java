package com.warhead;

import net.minecraftforge.common.ForgeConfigSpec;

/** User-adjustable performance and presentation settings (config/warhead-common.toml). */
public final class WarheadConfig {
    private WarheadConfig() {}
    private static final ForgeConfigSpec.Builder BUILDER = new ForgeConfigSpec.Builder();

    public static final ForgeConfigSpec.IntValue EFFECTS_LEVEL;
    public static final ForgeConfigSpec.BooleanValue SOUND_EFFECTS;
    public static final ForgeConfigSpec.BooleanValue CAMERA_SHAKE;
    public static final ForgeConfigSpec.IntValue BOMBER_DROP_INTERVAL;
    public static final ForgeConfigSpec.IntValue MAX_DEBRIS_PER_BLAST;
    public static final ForgeConfigSpec.BooleanValue ENABLE_DEBRIS;
    public static final ForgeConfigSpec.BooleanValue ENABLE_COLLAPSE;
    public static final ForgeConfigSpec.IntValue MAX_ACTIVE_BLASTS;
    public static final ForgeConfigSpec.IntValue PARTICLE_INTERVAL;
    public static final ForgeConfigSpec.DoubleValue SOUND_VOLUME;
    public static final ForgeConfigSpec.BooleanValue COLLAPSE_SOUNDS;
    public static final ForgeConfigSpec SPEC;

    static {
        BUILDER.push("performance_and_effects");
        EFFECTS_LEVEL = BUILDER.comment("Visual effect density: 0=minimum, 1=low, 2=normal, 3=high")
                .defineInRange("effectsLevel", 2, 0, 3);
        SOUND_EFFECTS = BUILDER.comment("Enable Warhead sound effects").define("soundEffects", true);
        CAMERA_SHAKE = BUILDER.comment("Enable blast camera shake").define("cameraShake", true);
        BOMBER_DROP_INTERVAL = BUILDER.comment("Ticks between bomber drops (20 ticks = 1 second)")
                .defineInRange("bomberDropInterval", 100, 40, 600);
        MAX_DEBRIS_PER_BLAST = BUILDER.comment("Maximum blocks turned into flying debris per blast; lower values improve performance")
                .defineInRange("maxDebrisPerBlast", 180, 0, 1200);
        ENABLE_DEBRIS = BUILDER.comment("Allow blocks to become moving debris").define("enableDebris", true);
        ENABLE_COLLAPSE = BUILDER.comment("Allow weak underground roofs to collapse after strong blasts").define("enableCollapse", true);
        MAX_ACTIVE_BLASTS = BUILDER.comment("Maximum active shockwaves per server level; excess chain blasts are ignored").defineInRange("maxActiveBlasts", 4, 1, 16);
        PARTICLE_INTERVAL = BUILDER.comment("Particle throttling: emit every N ticks for ongoing effects").defineInRange("particleInterval", 1, 1, 10);
        SOUND_VOLUME = BUILDER.comment("Warhead sound volume multiplier").defineInRange("soundVolume", 1.0, 0.0, 2.0);
        COLLAPSE_SOUNDS = BUILDER.comment("Play rubble and structural-collapse sounds (separate from explosion sounds)").define("collapseSounds", true);
        BUILDER.pop();
        SPEC = BUILDER.build();
    }
}
