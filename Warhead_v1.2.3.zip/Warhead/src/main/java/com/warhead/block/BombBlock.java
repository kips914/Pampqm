package com.warhead.block;

import com.warhead.blast.BlastManager;
import com.warhead.blast.BlastProfile;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.Vec3;

/** Бомба-блок: детонирует от редстоун-сигнала. (Сброс с бомбардировщика / ракеты — следующие этапы.) */
public class BombBlock extends Block {
    private final BlastProfile profile;

    public BombBlock(Properties props, BlastProfile profile) {
        super(props);
        this.profile = profile;
    }

    public BlastProfile profile() { return profile; }

    @Override
    public void onPlace(BlockState state, Level level, BlockPos pos, BlockState old, boolean moved) {
        if (!level.isClientSide && level.hasNeighborSignal(pos)) detonate(level, pos);
    }

    @Override
    public void neighborChanged(BlockState state, Level level, BlockPos pos, Block block, BlockPos from, boolean moved) {
        if (!level.isClientSide && level.hasNeighborSignal(pos)) detonate(level, pos);
    }

    private void detonate(Level level, BlockPos pos) {
        level.removeBlock(pos, false);
        BlastManager.start((ServerLevel) level, Vec3.atCenterOf(pos), profile);
    }
}
