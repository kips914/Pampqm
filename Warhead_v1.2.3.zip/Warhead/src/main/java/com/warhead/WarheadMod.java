package com.warhead;

import com.warhead.net.ModNet;
import com.warhead.registry.ModBlocks;
import com.warhead.registry.ModItems;
import com.warhead.registry.ModEntities;
import com.warhead.registry.ModTabs;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.ModLoadingContext;
import net.minecraftforge.fml.config.ModConfig;
import net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;

@Mod(WarheadMod.MODID)
public class WarheadMod {
    public static final String MODID = "warhead";

    public WarheadMod() {
        ModLoadingContext.get().registerConfig(ModConfig.Type.COMMON, WarheadConfig.SPEC);
        IEventBus bus = FMLJavaModLoadingContext.get().getModEventBus();
        ModBlocks.BLOCKS.register(bus);
        ModItems.ITEMS.register(bus);
        ModEntities.ENTITY_TYPES.register(bus);
        ModTabs.TABS.register(bus);
        bus.addListener(this::commonSetup);
    }

    private void commonSetup(FMLCommonSetupEvent e) {
        e.enqueueWork(ModNet::init);
    }
}
