package com.warhead.entity;

import com.warhead.WarheadMod;
import com.warhead.registry.ModEntities;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.Mob;
import net.minecraftforge.event.entity.EntityAttributeCreationEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = WarheadMod.MODID, bus = Mod.EventBusSubscriber.Bus.MOD)
public final class BomberAttributes {
    private BomberAttributes() {}
    @SubscribeEvent public static void registerAttributes(EntityAttributeCreationEvent event) {
        AttributeSupplier.Builder attributes = Mob.createMobAttributes()
                .add(Attributes.MAX_HEALTH, 60.0D)
                .add(Attributes.FLYING_SPEED, 0.6D)
                .add(Attributes.MOVEMENT_SPEED, 0.25D)
                .add(Attributes.KNOCKBACK_RESISTANCE, 1.0D);
        event.put(ModEntities.BOMBER.get(), attributes.build());
    }
}
