package com.warhead.blast;

/**
 * power     — "энергия" взрыва (см. ShockwaveBlast.pressure)
 * maxRadius — жёсткий предел расчёта в блоках (защита памяти)
 * radStrength / radRadius — радиация у эпицентра и радиус заражения (только ядерные)
 */
public enum BlastProfile {
    SMALL(1200f, false, 45, 0f, 0),
    HEAVY(6000f, false, 60, 0f, 0),
    NUKE(60000f, true, 100, 20f, 400);

    public final float power;
    public final boolean nuclear;
    public final int maxRadius;
    public final float radStrength;
    public final int radRadius;

    BlastProfile(float power, boolean nuclear, int maxRadius, float radStrength, int radRadius) {
        this.power = power;
        this.nuclear = nuclear;
        this.maxRadius = maxRadius;
        this.radStrength = radStrength;
        this.radRadius = radRadius;
    }
}
