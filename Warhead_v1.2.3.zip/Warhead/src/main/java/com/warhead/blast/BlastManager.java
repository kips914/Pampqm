package com.warhead.blast;

import com.warhead.WarheadMod;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.server.ServerStoppingEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

@Mod.EventBusSubscriber(modid = WarheadMod.MODID)
public class BlastManager {
    private static final List<ShockwaveBlast> ACTIVE = new ArrayList<>();
    private static final List<ShockwaveBlast> PENDING = new ArrayList<>();

    public static void start(ServerLevel level, Vec3 origin, BlastProfile profile) {
        long activeForLevel = ACTIVE.stream().filter(b -> b.level() == level).count()
                + PENDING.stream().filter(b -> b.level() == level).count();
        if (activeForLevel >= com.warhead.WarheadConfig.MAX_ACTIVE_BLASTS.get()) return;
        PENDING.add(new ShockwaveBlast(level, origin, profile));
    }

    @SubscribeEvent
    public static void onLevelTick(TickEvent.LevelTickEvent e) {
        if (e.phase != TickEvent.Phase.END || e.level.isClientSide) return;
        if (!PENDING.isEmpty()) { ACTIVE.addAll(PENDING); PENDING.clear(); }
        Iterator<ShockwaveBlast> it = ACTIVE.iterator();
        while (it.hasNext()) {
            ShockwaveBlast b = it.next();
            if (b.level() != e.level) continue;
            if (b.tick()) it.remove();
        }
    }

    @SubscribeEvent
    public static void onStopping(ServerStoppingEvent e) {
        ACTIVE.clear();
        PENDING.clear();
    }
}
