package com.warhead.registry;

import com.warhead.WarheadMod;
import com.warhead.blast.BlastProfile;
import com.warhead.block.BombBlock;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.RotatedPillarBlock;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.material.MapColor;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

import java.util.function.Supplier;

public class ModBlocks {
    public static final DeferredRegister<Block> BLOCKS = DeferredRegister.create(ForgeRegistries.BLOCKS, WarheadMod.MODID);

    /** Свинец: единственный блок, который останавливает радиацию. Очень высокая взрывоустойчивость. */
    public static final RegistryObject<Block> LEAD_BLOCK = reg("lead_block", () -> new Block(
            BlockBehaviour.Properties.of().mapColor(MapColor.COLOR_GRAY)
                    .strength(5f, 1200f).requiresCorrectToolForDrops().sound(SoundType.METAL)));

    /** Свинцовая руда для добычи свинца. */
    public static final RegistryObject<Block> LEAD_ORE = reg("lead_ore", () -> new Block(
            BlockBehaviour.Properties.of().mapColor(MapColor.STONE).strength(3f, 3f)
                    .requiresCorrectToolForDrops().sound(SoundType.STONE)));

    /** Пепельная земля после ядерного взрыва. */
    public static final RegistryObject<Block> ASH_GROUND = reg("ash_ground", () -> new Block(
            BlockBehaviour.Properties.of().mapColor(MapColor.COLOR_GRAY)
                    .strength(0.6f).sound(SoundType.GRAVEL)));

    /** Обугленное дерево. */
    public static final RegistryObject<Block> CHARRED_LOG = reg("charred_log", () -> new RotatedPillarBlock(
            BlockBehaviour.Properties.of().mapColor(MapColor.COLOR_BLACK)
                    .strength(2f).sound(SoundType.WOOD)));

    public static final RegistryObject<Block> BOMB_SMALL = reg("bomb_small", () -> new BombBlock(
            BlockBehaviour.Properties.of().mapColor(MapColor.COLOR_GREEN).strength(3f, 6f).sound(SoundType.METAL),
            BlastProfile.SMALL));
    public static final RegistryObject<Block> BOMB_HEAVY = reg("bomb_heavy", () -> new BombBlock(
            BlockBehaviour.Properties.of().mapColor(MapColor.COLOR_GREEN).strength(3f, 6f).sound(SoundType.METAL),
            BlastProfile.HEAVY));
    public static final RegistryObject<Block> BOMB_NUKE = reg("bomb_nuke", () -> new BombBlock(
            BlockBehaviour.Properties.of().mapColor(MapColor.COLOR_GRAY).strength(3f, 6f).sound(SoundType.METAL),
            BlastProfile.NUKE));

    private static RegistryObject<Block> reg(String name, Supplier<Block> sup) {
        RegistryObject<Block> b = BLOCKS.register(name, sup);
        ModItems.ITEMS.register(name, () -> new BlockItem(b.get(), new Item.Properties()));
        return b;
    }
}
