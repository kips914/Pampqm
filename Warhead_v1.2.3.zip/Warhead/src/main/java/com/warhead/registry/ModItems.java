package com.warhead.registry;

import com.warhead.WarheadMod;
import com.warhead.item.GeigerCounterItem;
import com.warhead.item.HazmatArmorMaterial;
import com.warhead.item.ModGameplayItems;
import net.minecraft.world.item.ArmorItem;
import net.minecraft.world.item.Item;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public class ModItems {
    public static final DeferredRegister<Item> ITEMS = DeferredRegister.create(ForgeRegistries.ITEMS, WarheadMod.MODID);

    public static final RegistryObject<Item> AIR_FILTER = ITEMS.register("air_filter", () -> new Item(new Item.Properties().stacksTo(16)));
    public static final RegistryObject<Item> GAS_MASK = ITEMS.register("gas_mask", () -> new Item(new Item.Properties().stacksTo(1)));
    public static final RegistryObject<Item> HAZMAT_HELMET = ITEMS.register("hazmat_helmet", () -> new ArmorItem(HazmatArmorMaterial.INSTANCE, ArmorItem.Type.HELMET, new Item.Properties()));
    public static final RegistryObject<Item> HAZMAT_CHEST = ITEMS.register("hazmat_chest", () -> new ArmorItem(HazmatArmorMaterial.INSTANCE, ArmorItem.Type.CHESTPLATE, new Item.Properties()));
    public static final RegistryObject<Item> HAZMAT_LEGS = ITEMS.register("hazmat_legs", () -> new ArmorItem(HazmatArmorMaterial.INSTANCE, ArmorItem.Type.LEGGINGS, new Item.Properties()));
    public static final RegistryObject<Item> HAZMAT_BOOTS = ITEMS.register("hazmat_boots", () -> new ArmorItem(HazmatArmorMaterial.INSTANCE, ArmorItem.Type.BOOTS, new Item.Properties()));
    public static final RegistryObject<Item> GEIGER_COUNTER = ITEMS.register("geiger_counter", GeigerCounterItem::new);
    public static final RegistryObject<Item> TARGET_MAP = ITEMS.register("target_map", ModGameplayItems.TargetMap::new);
    public static final RegistryObject<Item> COORDINATE_SHEET = ITEMS.register("coordinate_sheet", ModGameplayItems.CoordinateSheet::new);
    public static final RegistryObject<Item> MISSILE = ITEMS.register("missile", ModGameplayItems.Missile::new);
    public static final RegistryObject<Item> BOMBER_MODEL = ITEMS.register("bomber_model", ModGameplayItems.BomberController::new);
    public static final RegistryObject<Item> LEAD_INGOT = ITEMS.register("lead_ingot", () -> new Item(new Item.Properties()));
}
