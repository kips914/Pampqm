package com.warhead.registry;

import com.warhead.WarheadMod;
import com.warhead.entity.BomberEntity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public final class ModEntities {
    public static final DeferredRegister<EntityType<?>> ENTITY_TYPES =
            DeferredRegister.create(ForgeRegistries.ENTITY_TYPES, WarheadMod.MODID);
    public static final RegistryObject<EntityType<BomberEntity>> BOMBER = ENTITY_TYPES.register("bomber",
            () -> EntityType.Builder.<BomberEntity>of(BomberEntity::new, MobCategory.MONSTER)
                    .sized(2.8F, 0.9F).clientTrackingRange(12).updateInterval(2).fireImmune()
                    .build("warhead:bomber"));
    private ModEntities() {}
}
