package com.warhead.registry;

import com.warhead.WarheadMod;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.RegistryObject;

public class ModTabs {
    public static final DeferredRegister<CreativeModeTab> TABS =
            DeferredRegister.create(Registries.CREATIVE_MODE_TAB, WarheadMod.MODID);

    public static final RegistryObject<CreativeModeTab> MAIN = TABS.register("main", () ->
            CreativeModeTab.builder()
                    .title(Component.translatable("itemGroup.warhead"))
                    .icon(() -> new ItemStack(ModItems.GEIGER_COUNTER.get()))
                    .displayItems((params, out) -> {
                        out.accept(ModItems.AIR_FILTER.get()); out.accept(ModItems.GAS_MASK.get());
                        out.accept(ModItems.HAZMAT_HELMET.get()); out.accept(ModItems.HAZMAT_CHEST.get());
                        out.accept(ModItems.HAZMAT_LEGS.get()); out.accept(ModItems.HAZMAT_BOOTS.get());
                        out.accept(ModItems.GEIGER_COUNTER.get()); out.accept(ModItems.TARGET_MAP.get());
                        out.accept(ModItems.COORDINATE_SHEET.get()); out.accept(ModItems.LEAD_INGOT.get());
                    }).build());

    public static final RegistryObject<CreativeModeTab> ARSENAL = TABS.register("arsenal", () ->
            CreativeModeTab.builder()
                    .title(Component.translatable("itemGroup.warhead_arsenal"))
                    .icon(() -> new ItemStack(ModBlocks.BOMB_NUKE.get()))
                    .displayItems((params, out) -> {
                        out.accept(ModBlocks.BOMB_SMALL.get()); out.accept(ModBlocks.BOMB_HEAVY.get());
                        out.accept(ModBlocks.BOMB_NUKE.get()); out.accept(ModItems.MISSILE.get());
                        out.accept(ModItems.BOMBER_MODEL.get()); out.accept(ModBlocks.LEAD_ORE.get());
                        out.accept(ModBlocks.LEAD_BLOCK.get()); out.accept(ModBlocks.ASH_GROUND.get());
                        out.accept(ModBlocks.CHARRED_LOG.get());
                    }).build());
}
