package com.warhead.client;

import com.warhead.WarheadMod;
import com.warhead.client.model.BomberModel;
import com.warhead.client.renderer.BomberRenderer;
import com.warhead.entity.BomberEntity;
import com.warhead.registry.ModEntities;
import net.minecraft.client.renderer.entity.EntityRenderers;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.EntityRenderersEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = WarheadMod.MODID, bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public final class BomberClientEvents {
    private BomberClientEvents() {}
    @SubscribeEvent public static void registerLayers(EntityRenderersEvent.RegisterLayerDefinitions event) {
        event.registerLayerDefinition(BomberModel.LAYER, BomberModel::createLayer);
    }
    @SubscribeEvent public static void registerRenderers(EntityRenderersEvent.RegisterRenderers event) {
        event.registerEntityRenderer(ModEntities.BOMBER.get(), BomberRenderer::new);
    }
}
