package com.warhead.client.model;

import com.warhead.entity.BomberEntity;
import net.minecraft.client.model.EntityModel;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeDeformation;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;
import net.minecraft.resources.ResourceLocation;

/** Low-poly bomber silhouette: fuselage, swept wings, tail, engines, rotating propellers and landing gear. */
public class BomberModel extends EntityModel<BomberEntity> {
    public static final ModelLayerLocation LAYER = new ModelLayerLocation(new ResourceLocation("warhead", "bomber"), "main");
    private final ModelPart root, fuselage, leftProp, rightProp, gearLeft, gearRight, tail;

    public BomberModel(ModelPart root) {
        this.root = root;
        this.fuselage = root.getChild("fuselage");
        this.leftProp = root.getChild("left_prop");
        this.rightProp = root.getChild("right_prop");
        this.gearLeft = root.getChild("gear_left");
        this.gearRight = root.getChild("gear_right");
        this.tail = root.getChild("tail");
    }

    public static LayerDefinition createLayer() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition root = mesh.getRoot();
        root.addOrReplaceChild("fuselage", net.minecraft.client.model.geom.builders.CubeListBuilder.create()
                .texOffs(0, 0).addBox(-3.0F, -2.0F, -12.0F, 6.0F, 4.0F, 24.0F)
                .texOffs(0, 30).addBox(-2.0F, -3.0F, -4.0F, 4.0F, 2.0F, 8.0F)
                .texOffs(0, 42).addBox(-1.5F, -1.0F, -14.0F, 3.0F, 2.0F, 3.0F), PartPose.ZERO);
        root.addOrReplaceChild("wings", net.minecraft.client.model.geom.builders.CubeListBuilder.create()
                .texOffs(0, 50).addBox(-18.0F, -0.5F, -3.0F, 36.0F, 1.0F, 8.0F)
                .texOffs(0, 60).addBox(-15.0F, -0.2F, -5.0F, 30.0F, 0.5F, 2.0F), PartPose.ZERO);
        root.addOrReplaceChild("engines", net.minecraft.client.model.geom.builders.CubeListBuilder.create()
                .texOffs(0, 66).addBox(-13.0F, -1.5F, -1.0F, 4.0F, 3.0F, 7.0F)
                .addBox(9.0F, -1.5F, -1.0F, 4.0F, 3.0F, 7.0F), PartPose.ZERO);
        root.addOrReplaceChild("tail", net.minecraft.client.model.geom.builders.CubeListBuilder.create()
                .texOffs(40, 0).addBox(-1.0F, -0.5F, 9.0F, 2.0F, 1.0F, 8.0F)
                .texOffs(40, 12).addBox(-5.0F, -0.5F, 13.0F, 10.0F, 1.0F, 3.0F)
                .texOffs(40, 18).addBox(-1.0F, -4.0F, 13.0F, 2.0F, 4.0F, 3.0F), PartPose.ZERO);
        root.addOrReplaceChild("left_prop", net.minecraft.client.model.geom.builders.CubeListBuilder.create()
                .texOffs(64, 0).addBox(-0.5F, -5.0F, -0.5F, 1.0F, 10.0F, 1.0F)
                .texOffs(68, 0).addBox(-4.0F, -0.5F, -0.5F, 8.0F, 1.0F, 1.0F), PartPose.offset(-11.0F, 0.0F, -2.0F));
        root.addOrReplaceChild("right_prop", net.minecraft.client.model.geom.builders.CubeListBuilder.create()
                .texOffs(64, 0).addBox(-0.5F, -5.0F, -0.5F, 1.0F, 10.0F, 1.0F)
                .texOffs(68, 0).addBox(-4.0F, -0.5F, -0.5F, 8.0F, 1.0F, 1.0F), PartPose.offset(11.0F, 0.0F, -2.0F));
        root.addOrReplaceChild("gear_left", net.minecraft.client.model.geom.builders.CubeListBuilder.create()
                .texOffs(40, 24).addBox(-0.5F, 0.0F, -0.5F, 1.0F, 5.0F, 1.0F)
                .addBox(-1.5F, 4.0F, -1.5F, 3.0F, 1.0F, 3.0F), PartPose.offset(-7.0F, 1.0F, 2.0F));
        root.addOrReplaceChild("gear_right", net.minecraft.client.model.geom.builders.CubeListBuilder.create()
                .texOffs(40, 24).addBox(-0.5F, 0.0F, -0.5F, 1.0F, 5.0F, 1.0F)
                .addBox(-1.5F, 4.0F, -1.5F, 3.0F, 1.0F, 3.0F), PartPose.offset(7.0F, 1.0F, 2.0F));
        return LayerDefinition.create(mesh, 128, 96);
    }

    @Override public void setupAnim(BomberEntity entity, float limbSwing, float limbSwingAmount, float ageInTicks, float netHeadYaw, float headPitch) {
        leftProp.zRot = ageInTicks * 1.8F;
        rightProp.zRot = -ageInTicks * 1.8F;
        // Slight pitch bank makes the turn readable while propellers keep spinning.
        root.yRot = 0.0F;
        root.xRot = (float)Math.sin(ageInTicks * 0.035F) * 0.035F;
        float gearMotion = (float)Math.sin(ageInTicks * 0.025F) * 0.02F;
        gearLeft.xRot = gearMotion;
        gearRight.xRot = -gearMotion;
        tail.yRot = (float)Math.sin(ageInTicks * 0.02F) * 0.025F;
    }

    @Override public void renderToBuffer(com.mojang.blaze3d.vertex.PoseStack poseStack,
            com.mojang.blaze3d.vertex.VertexConsumer buffer, int packedLight, int packedOverlay,
            float red, float green, float blue, float alpha) {
        root.render(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
    }
}
