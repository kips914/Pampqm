package com.warhead.client;

import com.warhead.WarheadMod;
import com.warhead.WarheadConfig;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.ViewportEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/** Тряска камеры. Интенсивность затухает в последние 20 тиков. */
@Mod.EventBusSubscriber(modid = WarheadMod.MODID, value = Dist.CLIENT)
public class ClientShake {
    private static float intensity = 0f;
    private static int ticks = 0;

    public static void start(float i, int t) {
        intensity = Math.max(intensity, i);
        ticks = Math.max(ticks, t);
    }

    @SubscribeEvent
    public static void onClientTick(TickEvent.ClientTickEvent e) {
        if (e.phase != TickEvent.Phase.END) return;
        if (ticks > 0) ticks--; else intensity = 0f;
    }

    @SubscribeEvent
    public static void onCamera(ViewportEvent.ComputeCameraAngles e) {
        if (ticks <= 0 || !WarheadConfig.CAMERA_SHAKE.get()) return;
        float k = intensity * Math.min(1f, ticks / 20f) * 6f;
        e.setPitch(e.getPitch() + (float) (Math.random() - 0.5) * k);
        e.setYaw(e.getYaw() + (float) (Math.random() - 0.5) * k);
        e.setRoll(e.getRoll() + (float) (Math.random() - 0.5) * k);
    }
}
