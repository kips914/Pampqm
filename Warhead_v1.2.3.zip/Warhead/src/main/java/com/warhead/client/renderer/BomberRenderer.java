package com.warhead.client.renderer;

import com.warhead.client.model.BomberModel;
import com.warhead.entity.BomberEntity;
import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.resources.ResourceLocation;

public class BomberRenderer extends MobRenderer<BomberEntity, BomberModel> {
    private static final ResourceLocation TEXTURE = new ResourceLocation("warhead", "textures/entity/bomber.png");
    public BomberRenderer(EntityRendererProvider.Context context) {
        super(context, new BomberModel(context.bakeLayer(BomberModel.LAYER)), 1.25F);
    }
    @Override public ResourceLocation getTextureLocation(BomberEntity entity) { return TEXTURE; }
    @Override protected void scale(BomberEntity entity, PoseStack poseStack, float partialTick) {
        poseStack.scale(1.0F, 1.0F, 1.0F);
    }
}
