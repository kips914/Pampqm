package com.warhead.net;

import com.warhead.WarheadMod;
import net.minecraft.resources.ResourceLocation;
import net.minecraftforge.network.NetworkRegistry;
import net.minecraftforge.network.simple.SimpleChannel;

public class ModNet {
    private static final String VERSION = "1";
    public static final SimpleChannel CH = NetworkRegistry.newSimpleChannel(
            new ResourceLocation(WarheadMod.MODID, "main"), () -> VERSION, VERSION::equals, VERSION::equals);

    public static void init() {
        CH.registerMessage(0, ShakePacket.class, ShakePacket::encode, ShakePacket::decode, ShakePacket::handle);
    }
}
