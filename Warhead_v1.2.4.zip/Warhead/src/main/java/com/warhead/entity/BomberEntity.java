package com.warhead.entity;

import com.warhead.WarheadConfig;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.FlyingMob;
import net.minecraft.world.entity.MoverType;
import net.minecraft.world.entity.item.PrimedTnt;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;

/** One-pass bomber mission: hidden countdown, visible fly-by, one bomb drop, then despawn. */
public class BomberEntity extends FlyingMob {
    private static final int DEFAULT_COUNTDOWN_TICKS = 100;
    private int countdown = DEFAULT_COUNTDOWN_TICKS;
    private int flightTicks = 0;
    private boolean missionStarted = false;
    private boolean bombDropped = false;
    private Vec3 direction = new Vec3(0, 0, 1);
    private double targetX, targetY, targetZ;

    public BomberEntity(EntityType<? extends FlyingMob> type, Level level) {
        super(type, level);
        noPhysics = true;
        setNoGravity(true);
    }

    @Override protected void registerGoals() { }

    public void configureMission(double targetX, double targetY, double targetZ, Vec3 direction, int delayTicks) {
        this.targetX = targetX; this.targetY = targetY; this.targetZ = targetZ;
        this.direction = new Vec3(direction.x, 0, direction.z).normalize();
        if (this.direction.lengthSqr() < 0.01) this.direction = new Vec3(0, 0, 1);
        this.countdown = Math.max(20, delayTicks);
        this.flightTicks = 0;
        this.missionStarted = false;
        this.bombDropped = false;
        setInvisible(true);
        var data = getPersistentData();
        data.putBoolean("WarheadMission", true);
        data.putDouble("MissionTargetX", targetX); data.putDouble("MissionTargetY", targetY); data.putDouble("MissionTargetZ", targetZ);
        data.putDouble("MissionDirX", this.direction.x); data.putDouble("MissionDirZ", this.direction.z);
        data.putInt("MissionCountdown", countdown); data.putInt("MissionFlightTicks", 0);
        data.putBoolean("MissionStarted", false); data.putBoolean("MissionBombDropped", false);
    }

    @Override public void tick() {
        super.tick();
        if (level().isClientSide) return;
        var data = getPersistentData();
        if (!data.getBoolean("WarheadMission")) { discard(); return; }
        targetX = data.getDouble("MissionTargetX"); targetY = data.getDouble("MissionTargetY"); targetZ = data.getDouble("MissionTargetZ");
        direction = new Vec3(data.getDouble("MissionDirX"), 0, data.getDouble("MissionDirZ")).normalize();
        countdown = data.getInt("MissionCountdown"); flightTicks = data.getInt("MissionFlightTicks");
        missionStarted = data.getBoolean("MissionStarted"); bombDropped = data.getBoolean("MissionBombDropped");

        if (!missionStarted) {
            countdown--;
            data.putInt("MissionCountdown", countdown);
            if (countdown <= 0) {
                missionStarted = true; data.putBoolean("MissionStarted", true);
                setInvisible(false);
                setPos(targetX - direction.x * 58.0, targetY + 30.0, targetZ - direction.z * 58.0);
                if (WarheadConfig.SOUND_EFFECTS.get() && level() instanceof ServerLevel server)
                    server.playSound(null, blockPosition(), SoundEvents.ELYTRA_FLYING, SoundSource.HOSTILE,
                            (float)(0.9 * WarheadConfig.SOUND_VOLUME.get()), 0.65F);
            }
            return;
        }

        flightTicks++;
        data.putInt("MissionFlightTicks", flightTicks);
        double speed = 0.68;
        Vec3 motion = direction.scale(speed);
        setDeltaMovement(motion);
        move(MoverType.SELF, motion);
        float yaw = (float)(Math.atan2(-direction.x, direction.z) * 180.0 / Math.PI);
        setYRot(yaw); yRotO = yaw; setYBodyRot(yaw);

        int quality = WarheadConfig.EFFECTS_LEVEL.get();
        int trailInterval = quality == 3 ? 2 : quality == 2 ? 5 : quality == 1 ? 12 : Integer.MAX_VALUE;
        if (quality > 0 && tickCount % trailInterval == 0 && level() instanceof ServerLevel server)
            server.sendParticles(ParticleTypes.CLOUD, getX(), getY() - 0.3, getZ(), quality >= 3 ? 2 : 1, 0.15, 0.05, 0.15, 0.002);

        // Drop once while passing above the marked position, then continue flying away.
        double alongTrack = (getX() - (targetX - direction.x * 58.0)) * direction.x
                + (getZ() - (targetZ - direction.z * 58.0)) * direction.z;
        if (!bombDropped && alongTrack >= 52.0) {
            PrimedTnt bomb = new PrimedTnt(level(), getX(), getY() - 1.1, getZ(), null);
            bomb.setFuse(60);
            bomb.setDeltaMovement(direction.x * 0.22, -0.16, direction.z * 0.22);
            level().addFreshEntity(bomb);
            bombDropped = true; data.putBoolean("MissionBombDropped", true);
            if (WarheadConfig.SOUND_EFFECTS.get() && level() instanceof ServerLevel server)
                server.playSound(null, blockPosition(), SoundEvents.TNT_PRIMED, SoundSource.HOSTILE,
                        (float)(0.8 * WarheadConfig.SOUND_VOLUME.get()), 0.85F);
        }
        if (flightTicks > 190) discard();
    }

    @Override protected void addAdditionalSaveData(net.minecraft.nbt.CompoundTag tag) {
        super.addAdditionalSaveData(tag);
        tag.putInt("MissionCountdownLocal", countdown); tag.putInt("MissionFlightTicksLocal", flightTicks);
        tag.putBoolean("MissionStartedLocal", missionStarted); tag.putBoolean("MissionBombDroppedLocal", bombDropped);
    }
    @Override protected void readAdditionalSaveData(net.minecraft.nbt.CompoundTag tag) {
        super.readAdditionalSaveData(tag);
        countdown = tag.getInt("MissionCountdownLocal"); flightTicks = tag.getInt("MissionFlightTicksLocal");
        missionStarted = tag.getBoolean("MissionStartedLocal"); bombDropped = tag.getBoolean("MissionBombDroppedLocal");
    }

    @Override public boolean causeFallDamage(float distance, float multiplier, net.minecraft.world.damagesource.DamageSource source) { return false; }
    @Override protected net.minecraft.sounds.SoundEvent getAmbientSound() { return SoundEvents.ELYTRA_FLYING; }
    @Override protected net.minecraft.sounds.SoundEvent getHurtSound(net.minecraft.world.damagesource.DamageSource source) { return SoundEvents.METAL_HIT; }
    @Override protected net.minecraft.sounds.SoundEvent getDeathSound() { return SoundEvents.METAL_BREAK; }
    @Override public boolean isPushable() { return false; }
    @Override public boolean canBeLeashed(net.minecraft.world.entity.player.Player player) { return false; }
}
